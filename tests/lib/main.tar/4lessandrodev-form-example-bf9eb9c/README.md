# form-example
a simple example how to get form data with javascript
